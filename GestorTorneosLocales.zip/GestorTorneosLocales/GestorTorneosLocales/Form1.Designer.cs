namespace GestorTorneosLocales
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitulo = new System.Windows.Forms.Label();
            this.btnReiniciarTorneo = new System.Windows.Forms.Button();
            this.gbEquipo = new System.Windows.Forms.GroupBox();
            this.btnAgregarEquipo = new System.Windows.Forms.Button();
            this.txtCapitan = new System.Windows.Forms.TextBox();
            this.lblCapitan = new System.Windows.Forms.Label();
            this.txtNombreEquipo = new System.Windows.Forms.TextBox();
            this.lblNombreEquipo = new System.Windows.Forms.Label();
            this.dgvEquipos = new System.Windows.Forms.DataGridView();
            this.gbPartido = new System.Windows.Forms.GroupBox();
            this.btnGuardarResultado = new System.Windows.Forms.Button();
            this.txtGolesVisitante = new System.Windows.Forms.TextBox();
            this.lblGolesVisitante = new System.Windows.Forms.Label();
            this.txtGolesLocal = new System.Windows.Forms.TextBox();
            this.lblGolesLocal = new System.Windows.Forms.Label();
            this.cbEquipoVisitante = new System.Windows.Forms.ComboBox();
            this.lblEquipoVisitante = new System.Windows.Forms.Label();
            this.cbEquipoLocal = new System.Windows.Forms.ComboBox();
            this.lblEquipoLocal = new System.Windows.Forms.Label();
            this.dgvPartidos = new System.Windows.Forms.DataGridView();
            this.btnGenerarCalendario = new System.Windows.Forms.Button();
            this.btnActualizarTabla = new System.Windows.Forms.Button();
            this.lblMensaje = new System.Windows.Forms.Label();
            this.gbEquipo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEquipos)).BeginInit();
            this.gbPartido.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPartidos)).BeginInit();
            this.SuspendLayout();
            //
            // lblTitulo
            //
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(20, 15);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(431, 29);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "Gestor de Torneos Locales";
            //
            // btnReiniciarTorneo
            //
            this.btnReiniciarTorneo.Location = new System.Drawing.Point(784, 20);
            this.btnReiniciarTorneo.Name = "btnReiniciarTorneo";
            this.btnReiniciarTorneo.Size = new System.Drawing.Size(196, 35);
            this.btnReiniciarTorneo.TabIndex = 8;
            this.btnReiniciarTorneo.Text = "Reiniciar Torneo";
            this.btnReiniciarTorneo.UseVisualStyleBackColor = true;
            this.btnReiniciarTorneo.Click += new System.EventHandler(this.btnReiniciarTorneo_Click);
            //
            // gbEquipo
            //
            this.gbEquipo.Controls.Add(this.btnAgregarEquipo);
            this.gbEquipo.Controls.Add(this.txtCapitan);
            this.gbEquipo.Controls.Add(this.lblCapitan);
            this.gbEquipo.Controls.Add(this.txtNombreEquipo);
            this.gbEquipo.Controls.Add(this.lblNombreEquipo);
            this.gbEquipo.Location = new System.Drawing.Point(20, 60);
            this.gbEquipo.Name = "gbEquipo";
            this.gbEquipo.Size = new System.Drawing.Size(440, 160);
            this.gbEquipo.TabIndex = 1;
            this.gbEquipo.TabStop = false;
            this.gbEquipo.Text = "Registrar Equipo";
            //
            // btnAgregarEquipo
            //
            this.btnAgregarEquipo.Location = new System.Drawing.Point(170, 110);
            this.btnAgregarEquipo.Name = "btnAgregarEquipo";
            this.btnAgregarEquipo.Size = new System.Drawing.Size(160, 35);
            this.btnAgregarEquipo.TabIndex = 4;
            this.btnAgregarEquipo.Text = "Agregar Equipo";
            this.btnAgregarEquipo.UseVisualStyleBackColor = true;
            this.btnAgregarEquipo.Click += new System.EventHandler(this.btnAgregarEquipo_Click);
            //
            // txtCapitan
            //
            this.txtCapitan.Location = new System.Drawing.Point(170, 67);
            this.txtCapitan.Name = "txtCapitan";
            this.txtCapitan.Size = new System.Drawing.Size(240, 27);
            this.txtCapitan.TabIndex = 3;
            //
            // lblCapitan
            //
            this.lblCapitan.AutoSize = true;
            this.lblCapitan.Location = new System.Drawing.Point(15, 70);
            this.lblCapitan.Name = "lblCapitan";
            this.lblCapitan.Size = new System.Drawing.Size(133, 20);
            this.lblCapitan.TabIndex = 2;
            this.lblCapitan.Text = "Nombre del Capitán";
            //
            // txtNombreEquipo
            //
            this.txtNombreEquipo.Location = new System.Drawing.Point(170, 27);
            this.txtNombreEquipo.Name = "txtNombreEquipo";
            this.txtNombreEquipo.Size = new System.Drawing.Size(240, 27);
            this.txtNombreEquipo.TabIndex = 1;
            //
            // lblNombreEquipo
            //
            this.lblNombreEquipo.AutoSize = true;
            this.lblNombreEquipo.Location = new System.Drawing.Point(15, 30);
            this.lblNombreEquipo.Name = "lblNombreEquipo";
            this.lblNombreEquipo.Size = new System.Drawing.Size(140, 20);
            this.lblNombreEquipo.TabIndex = 0;
            this.lblNombreEquipo.Text = "Nombre del Equipo";
            //
            // dgvEquipos
            //
            this.dgvEquipos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvEquipos.Location = new System.Drawing.Point(20, 235);
            this.dgvEquipos.Name = "dgvEquipos";
            this.dgvEquipos.RowTemplate.Height = 28;
            this.dgvEquipos.Size = new System.Drawing.Size(440, 300);
            this.dgvEquipos.TabIndex = 2;
            //
            // gbPartido
            //
            this.gbPartido.Controls.Add(this.btnGuardarResultado);
            this.gbPartido.Controls.Add(this.txtGolesVisitante);
            this.gbPartido.Controls.Add(this.lblGolesVisitante);
            this.gbPartido.Controls.Add(this.txtGolesLocal);
            this.gbPartido.Controls.Add(this.lblGolesLocal);
            this.gbPartido.Controls.Add(this.cbEquipoVisitante);
            this.gbPartido.Controls.Add(this.lblEquipoVisitante);
            this.gbPartido.Controls.Add(this.cbEquipoLocal);
            this.gbPartido.Controls.Add(this.lblEquipoLocal);
            this.gbPartido.Location = new System.Drawing.Point(480, 60);
            this.gbPartido.Name = "gbPartido";
            this.gbPartido.Size = new System.Drawing.Size(500, 200);
            this.gbPartido.TabIndex = 3;
            this.gbPartido.TabStop = false;
            this.gbPartido.Text = "Registrar Resultado de Partido";
            //
            // btnGuardarResultado
            //
            this.btnGuardarResultado.Location = new System.Drawing.Point(170, 150);
            this.btnGuardarResultado.Name = "btnGuardarResultado";
            this.btnGuardarResultado.Size = new System.Drawing.Size(200, 35);
            this.btnGuardarResultado.TabIndex = 8;
            this.btnGuardarResultado.Text = "Guardar Resultado";
            this.btnGuardarResultado.UseVisualStyleBackColor = true;
            this.btnGuardarResultado.Click += new System.EventHandler(this.btnGuardarResultado_Click);
            //
            // txtGolesVisitante
            //
            this.txtGolesVisitante.Location = new System.Drawing.Point(400, 107);
            this.txtGolesVisitante.MaxLength = 2;
            this.txtGolesVisitante.Name = "txtGolesVisitante";
            this.txtGolesVisitante.Size = new System.Drawing.Size(80, 27);
            this.txtGolesVisitante.TabIndex = 7;
            //
            // lblGolesVisitante
            //
            this.lblGolesVisitante.AutoSize = true;
            this.lblGolesVisitante.Location = new System.Drawing.Point(270, 110);
            this.lblGolesVisitante.Name = "lblGolesVisitante";
            this.lblGolesVisitante.Size = new System.Drawing.Size(119, 20);
            this.lblGolesVisitante.TabIndex = 6;
            this.lblGolesVisitante.Text = "Goles Visitante";
            //
            // txtGolesLocal
            //
            this.txtGolesLocal.Location = new System.Drawing.Point(170, 107);
            this.txtGolesLocal.MaxLength = 2;
            this.txtGolesLocal.Name = "txtGolesLocal";
            this.txtGolesLocal.Size = new System.Drawing.Size(80, 27);
            this.txtGolesLocal.TabIndex = 5;
            //
            // lblGolesLocal
            //
            this.lblGolesLocal.AutoSize = true;
            this.lblGolesLocal.Location = new System.Drawing.Point(15, 110);
            this.lblGolesLocal.Name = "lblGolesLocal";
            this.lblGolesLocal.Size = new System.Drawing.Size(93, 20);
            this.lblGolesLocal.TabIndex = 4;
            this.lblGolesLocal.Text = "Goles Local";
            //
            // cbEquipoVisitante
            //
            this.cbEquipoVisitante.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbEquipoVisitante.FormattingEnabled = true;
            this.cbEquipoVisitante.Location = new System.Drawing.Point(170, 67);
            this.cbEquipoVisitante.Name = "cbEquipoVisitante";
            this.cbEquipoVisitante.Size = new System.Drawing.Size(310, 28);
            this.cbEquipoVisitante.TabIndex = 3;
            //
            // lblEquipoVisitante
            //
            this.lblEquipoVisitante.AutoSize = true;
            this.lblEquipoVisitante.Location = new System.Drawing.Point(15, 70);
            this.lblEquipoVisitante.Name = "lblEquipoVisitante";
            this.lblEquipoVisitante.Size = new System.Drawing.Size(133, 20);
            this.lblEquipoVisitante.TabIndex = 2;
            this.lblEquipoVisitante.Text = "Equipo Visitante";
            //
            // cbEquipoLocal
            //
            this.cbEquipoLocal.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbEquipoLocal.FormattingEnabled = true;
            this.cbEquipoLocal.Location = new System.Drawing.Point(170, 27);
            this.cbEquipoLocal.Name = "cbEquipoLocal";
            this.cbEquipoLocal.Size = new System.Drawing.Size(310, 28);
            this.cbEquipoLocal.TabIndex = 1;
            //
            // lblEquipoLocal
            //
            this.lblEquipoLocal.AutoSize = true;
            this.lblEquipoLocal.Location = new System.Drawing.Point(15, 30);
            this.lblEquipoLocal.Name = "lblEquipoLocal";
            this.lblEquipoLocal.Size = new System.Drawing.Size(103, 20);
            this.lblEquipoLocal.TabIndex = 0;
            this.lblEquipoLocal.Text = "Equipo Local";
            //
            // dgvPartidos
            //
            this.dgvPartidos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPartidos.Location = new System.Drawing.Point(480, 275);
            this.dgvPartidos.Name = "dgvPartidos";
            this.dgvPartidos.RowTemplate.Height = 28;
            this.dgvPartidos.Size = new System.Drawing.Size(500, 260);
            this.dgvPartidos.TabIndex = 4;
            //
            // btnGenerarCalendario
            //
            this.btnGenerarCalendario.Location = new System.Drawing.Point(480, 550);
            this.btnGenerarCalendario.Name = "btnGenerarCalendario";
            this.btnGenerarCalendario.Size = new System.Drawing.Size(200, 35);
            this.btnGenerarCalendario.TabIndex = 5;
            this.btnGenerarCalendario.Text = "Generar Calendario";
            this.btnGenerarCalendario.UseVisualStyleBackColor = true;
            this.btnGenerarCalendario.Click += new System.EventHandler(this.btnGenerarCalendario_Click);
            //
            // btnActualizarTabla
            //
            this.btnActualizarTabla.Location = new System.Drawing.Point(700, 550);
            this.btnActualizarTabla.Name = "btnActualizarTabla";
            this.btnActualizarTabla.Size = new System.Drawing.Size(200, 35);
            this.btnActualizarTabla.TabIndex = 6;
            this.btnActualizarTabla.Text = "Actualizar Tabla";
            this.btnActualizarTabla.UseVisualStyleBackColor = true;
            this.btnActualizarTabla.Click += new System.EventHandler(this.btnActualizarTabla_Click);
            //
            // lblMensaje
            //
            this.lblMensaje.Location = new System.Drawing.Point(20, 550);
            this.lblMensaje.Name = "lblMensaje";
            this.lblMensaje.Size = new System.Drawing.Size(440, 60);
            this.lblMensaje.TabIndex = 7;
            //
            // Form1
            //
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1004, 621);
            this.Controls.Add(this.lblMensaje);
            this.Controls.Add(this.btnActualizarTabla);
            this.Controls.Add(this.btnGenerarCalendario);
            this.Controls.Add(this.dgvPartidos);
            this.Controls.Add(this.gbPartido);
            this.Controls.Add(this.dgvEquipos);
            this.Controls.Add(this.gbEquipo);
            this.Controls.Add(this.lblTitulo);
            this.Controls.Add(this.btnReiniciarTorneo);
            this.Name = "Form1";
            this.Text = "Gestor de Torneos Locales";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.gbEquipo.ResumeLayout(false);
            this.gbEquipo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEquipos)).EndInit();
            this.gbPartido.ResumeLayout(false);
            this.gbPartido.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPartidos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Button btnReiniciarTorneo;
        private System.Windows.Forms.GroupBox gbEquipo;
        private System.Windows.Forms.Button btnAgregarEquipo;
        private System.Windows.Forms.TextBox txtCapitan;
        private System.Windows.Forms.Label lblCapitan;
        private System.Windows.Forms.TextBox txtNombreEquipo;
        private System.Windows.Forms.Label lblNombreEquipo;
        private System.Windows.Forms.DataGridView dgvEquipos;
        private System.Windows.Forms.GroupBox gbPartido;
        private System.Windows.Forms.Button btnGuardarResultado;
        private System.Windows.Forms.TextBox txtGolesVisitante;
        private System.Windows.Forms.Label lblGolesVisitante;
        private System.Windows.Forms.TextBox txtGolesLocal;
        private System.Windows.Forms.Label lblGolesLocal;
        private System.Windows.Forms.ComboBox cbEquipoVisitante;
        private System.Windows.Forms.Label lblEquipoVisitante;
        private System.Windows.Forms.ComboBox cbEquipoLocal;
        private System.Windows.Forms.Label lblEquipoLocal;
        private System.Windows.Forms.DataGridView dgvPartidos;
        private System.Windows.Forms.Button btnGenerarCalendario;
        private System.Windows.Forms.Button btnActualizarTabla;
        private System.Windows.Forms.Label lblMensaje;
    }
}
